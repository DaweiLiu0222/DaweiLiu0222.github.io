This file is submitted by Dawei Liu.  The MATLAB is used in the whole project.

What is included in my file:
(1) README.TXT

(2) A Folder named 'code' which contains all function and program.
    3 Function: NextState, TrajectoryGenerator, FeedbackControl
    3 Main program for best, newTask and overshoot respectively. 
       (I'm sorry that I don't know how to make log file. 
        The plot and csv file in each directory can be obtained by running the corresponding mian program in code file)

(3) A Folder named 'results' contains three required directories. In each directory, the following files are included:
      CSV file for end-effector trajectory and Xerror
      README.txt
      Videos
      Plot for Xerror in pdf







(